-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: ticketsystem
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `userFullName` varchar(150) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(20) DEFAULT '1234',
  `roleId` int DEFAULT NULL,
  `statusId` int DEFAULT '1',
  PRIMARY KEY (`userId`,`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Anthony Bloom','Anthony_Bloom2952@gembat.biz','1234',1,1),(2,'Ron Giles','Ron_Giles8783@grannar.com','1234',2,1),(3,'Percy Hunt','Percy_Hunt413@twipet.com','1234',3,1),(4,'Eden Forth','Eden_Forth2587@ovock.tech','1234',1,1),(5,'Margaret Bell','Margaret_Bell6422@fuliss.net','1234',2,1),(6,'Juliet Redwood','Juliet_Redwood3952@womeona.net','1234',3,1),(7,'David Wilde','David_Wilde6493@twipet.com','1234',2,1),(8,'Crystal Amstead','Crystal_Amstead223@deavo.com','1234',3,1),(9,'Enoch Hood','Enoch_Hood8785@joiniaa.com','1234',3,1),(10,'Rosie Sylvester','Rosie_Sylvester6324@sveldo.biz','1234',3,1),(11,'Margot Mcgee','Margot_Mcgee4142@zorer.org','1234',3,1),(12,'Brad Holmes','Brad_Holmes4506@fuliss.net','1234',2,1),(13,'Carter Pope','Carter_Pope4266@atink.com','1234',3,1),(14,'David Powell','David_Powell4849@guentu.biz','1234',2,1),(15,'Javier Rogan','Javier_Rogan4961@naiker.biz','1234',3,1),(16,'Mason Ashley','Mason_Ashley6342@grannar.com','1234',3,1),(17,'Johnathan John','Johnathan_John9145@fuliss.net','1234',3,1),(18,'Martin Alcroft','Martin_Alcroft6035@guentu.biz','1234',3,1),(19,'Caleb Dale','Caleb_Dale3280@extex.org','1234',2,1),(20,'Adela Bailey','Adela_Bailey1132@extex.org','1234',3,1),(21,'test','test@g.com','1234',3,1),(22,'Test','Test@g.com','ABCD',2,1),(23,'Test1','Test1@g.com','A1BCD',2,1),(24,'Sayani Roy','sayani.roy.97@gmail.com','1234',2,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-04 17:58:57
